# Sidebar Menu Submenus
## [Watch it on youtube](https://youtu.be/8tSbE3X29kQ)
### Sidebar Menu Submenus

- Sidebar Menu With Submenu Using HTML CSS & JavaScript
- Contains a menu to expand the sidebar.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
