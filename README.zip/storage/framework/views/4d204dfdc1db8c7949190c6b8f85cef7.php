

<?php $__env->startSection('title', 'HOME'); ?>

<?php $__env->startSection('content'); ?>


<img src="<?php echo e(asset('image/smk1.jpg')); ?>" width="400px">
<img src="<?php echo e(asset('image/smk.jpeg')); ?>" width="400px">
<br>
<h1>SMKN 4 BOGOR</h1>
<p>
Jl. Raya Tajur, Kp. Buntar RT.02/RW.08, Kel. Muara sari, Kec. Bogor Selatan, RT.03/RW.08, Muarasari, Kec. Bogor Sel., Kota Bogor, Jawa Barat 16137
</p>
<br>
<img src="<?php echo e(asset('image/bg.jpg')); ?>" width="400px">
<img src="<?php echo e(asset('image/12311.png')); ?>" width="400px">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel8\resources\views/v_home.blade.php ENDPATH**/ ?>