

<?php $__env->startSection('title', 'SISWA'); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>NO</th>
            <th>NIS</th>
            <th>NAMA SISWA</th>
            <th>KELAS</th>
            <th>MAPEL</th>
        </tr>
    </thead>
    <tbody>
        <?php $no=1; ?>
        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($data->nis); ?></td>
            <td><?php echo e($data->nama_siswa); ?></td>
            <td><?php echo e($data->kelas); ?></td>
            <td><?php echo e($data->mapel); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel8\resources\views/v_siswa.blade.php ENDPATH**/ ?>