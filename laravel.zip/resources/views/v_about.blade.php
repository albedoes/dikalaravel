@extends('layout.v_template')

@section('title','About')

@section('content')
<h1>Ini halaman guru</h1>
@endsection

