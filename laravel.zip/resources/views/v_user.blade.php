@extends('layout.v_template')

@section('title', 'USER')

@section('content')
<h1>Gada isinya :(<h1>
@endsection