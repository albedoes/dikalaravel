@extends('layout.v_template')

@section('title', 'HOME')

@section('content')


<img src="{{asset('image/smk1.jpg')}}" width="400px">
<img src="{{asset('image/smk.jpeg')}}" width="400px">
<br>
<h1>SMKN 4 BOGOR</h1>
<p>
Jl. Raya Tajur, Kp. Buntar RT.02/RW.08, Kel. Muara sari, Kec. Bogor Selatan, RT.03/RW.08, Muarasari, Kec. Bogor Sel., Kota Bogor, Jawa Barat 16137
</p>
<br>
<img src="{{asset('image/bg.jpg')}}" width="400px">
<img src="{{asset('image/12311.png')}}" width="400px">
@endsection
